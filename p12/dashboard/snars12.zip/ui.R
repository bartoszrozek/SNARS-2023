## ui.R ##
library(shinydashboard)

dashboardPage(
    dashboardHeader(),
    dashboardSidebar(),
    dashboardBody()
)